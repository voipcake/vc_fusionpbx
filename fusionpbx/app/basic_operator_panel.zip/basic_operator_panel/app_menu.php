<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Operator Panel";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Operator Panel";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Bedienfeld";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Bedienfeld";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Panneau Operateur";
	$apps[$x]['menu'][$y]['title']['he-il'] = "לוח מפעיל";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Pannello Operatore";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Bedienings paneel";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Panel operatora";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Painel do operador";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Панель оператора";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Telefonist Panel";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Панель оператора";
	$apps[$x]['menu'][$y]['uuid'] = "dd3d173a-5d51-4231-ab22-b18c5b712bb2";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/basic_operator_panel/index.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";
	$apps[$x]['menu'][$y]['groups'][] = "admin";

?>
